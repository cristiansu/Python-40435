from setuptools import setup

setup(
    name='Paquete1',
    version='1.0',
    description='Primer paquete distribuido',
    author='cs',
    author_email='saavedra_cristian@hotmail.com',
    packages=['Paquete1']
)